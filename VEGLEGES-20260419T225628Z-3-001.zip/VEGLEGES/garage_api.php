<?php
session_start();
header('Content-Type: application/json');
$conn = new mysqli("localhost", "root", "", "auto_piac");

if (!isset($_SESSION['user_id'])) {
    die(json_encode(["error" => "Nincs bejelentkezve"]));
}

$user_id = $_SESSION['user_id'];
$method = $_SERVER['REQUEST_METHOD'];

if ($method == 'GET') {
    // Garázs tartalmának lekérése
    $res = $conn->query("SELECT car_id FROM garage WHERE user_id = $user_id");
    $ids = [];
    while($row = $res->fetch_assoc()) $ids[] = (int)$row['car_id'];
    echo json_encode($ids);

} else if ($method == 'POST') {
    // Autó hozzáadása vagy törlése
    $data = json_decode(file_get_contents('php://input'), true);
    $car_id = (int)$data['car_id'];

    if ($data['action'] == 'add') {
        $conn->query("INSERT IGNORE INTO garage (user_id, car_id) VALUES ($user_id, $car_id)");
    } else {
        $conn->query("DELETE FROM garage WHERE user_id = $user_id AND car_id = $car_id");
    }
    echo json_encode(["success" => true]);
}
?>