<?php
session_start();
header('Content-Type: application/json');

// Adatbázis kapcsolat
$conn = new mysqli("localhost", "root", "", "auto_piac");
$conn->set_charset("utf8mb4");

if ($conn->connect_error) {
    die(json_encode(["success" => false, "message" => "Adatbázis hiba"]));
}

$data = json_decode(file_get_contents('php://input'), true);
$action = $data['action'] ?? '';

if ($action == 'register') {
    $username = $conn->real_escape_string($data['username']);
    $email = $conn->real_escape_string($data['email']); // ÚJ SOR
    $password = $data['password'];

    // 1. Validáció: Ne legyen üres
    if (empty($username) || empty($email) || empty($password)) {
        echo json_encode(["success" => false, "message" => "Minden mezőt ki kell tölteni!"]);
        exit;
    }

    // 2. Validáció: Email formátum ellenőrzése
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        echo json_encode(["success" => false, "message" => "Érvénytelen email formátum!"]);
        exit;
    }

    $hash = password_hash($password, PASSWORD_DEFAULT);
    
    // 3. Mentés az adatbázisba (Hozzáadva az email oszlop)
    $sql = "INSERT INTO users (username, email, password) VALUES ('$username', '$email', '$hash')";
    
    if ($conn->query($sql)) {
        echo json_encode(["success" => true, "message" => "Sikeres regisztráció!"]);
    } else {
        echo json_encode(["success" => false, "message" => "A felhasználónév vagy az email már foglalt!"]);
    }

} elseif ($action == 'login') {
    $username = $conn->real_escape_string($data['username']);
    $password = $data['password'];

    $result = $conn->query("SELECT * FROM users WHERE username = '$username'");
    $user = $result->fetch_assoc();

    if ($user && password_verify($password, $user['password'])) {
        $_SESSION['user_id'] = $user['id'];
        $_SESSION['username'] = $user['username'];
        echo json_encode(["success" => true, "username" => $user['username']]);
    } else {
        echo json_encode(["success" => false, "message" => "Hibás felhasználónév vagy jelszó!"]);
    }
}
?>