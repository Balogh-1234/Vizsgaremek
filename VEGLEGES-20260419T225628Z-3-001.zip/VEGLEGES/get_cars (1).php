<?php
$host = "localhost";
$user = "root";
$pass = ""; // XAMPP esetén üres
$db   = "auto_piac";

$conn = new mysqli($host, $user, $pass, $db);
$conn->set_charset("utf8mb4");

if ($conn->connect_error) {
    die(json_encode(["error" => "Hiba: " . $conn->connect_error]));
}

$result = $conn->query("SELECT * FROM cars");
$cars = [];

while($row = $result->fetch_assoc()) {
    $cars[] = $row;
}

header('Content-Type: application/json');
echo json_encode($cars);
?>